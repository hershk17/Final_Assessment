function validateInfo(form)
{
    var success = true;
    //  variable to store & display status after form submission
    var status = "<p><ul>";

    //  getting password element and value for necessary validation check
    var passElem = form.pass;
    var pass2Elem = form.confirmPass;
    var pass = form.pass.value;

    //  first password is checked for matching required syntax
    if(!validatePass(pass)) {
        //  status update is added if incorrect
        status += "<li>Invalid password, please choose a password with 6 characters (beginning with alphabet), 1 digit, and 1 uppercase character.";
        success = false;
        passElem.focus();
        passElem.select(); 
    }
    else {
        var pass2 = form.confirmPass.value;
        //  second password is checked to match 'valid' first password
        if(!confirmPass(pass, pass2)) {
            //  status update is added if incorrect
            status += "<li>Passwords do not match.";
            success = false;
            pass2Elem.focus();
            pass2Elem.select(); 
        }
        //  ***second password will only be checked for match if original was valid***
    }

    //  getting username element and value for necessary validation check
    var userElem = form.uName;
    var userID = form.uName.value;
    //  username is checked for matching required syntax
    if(!validateUserID(userID)) {
        //  status update is added if incorrect
        status += "<li>Invalid username, please choose a username with minimum 6 characters (beginning with alphabet).";
        if(success) {
            //  only focuses and selects if previous check was not an error (would otherwise only focus this element)
            userElem.focus();
            userElem.select();
        } 
        success = false;
    }  

    //  status update is added if validation was successful and corresponding alert is displayed
    if(success) {
        status = "<p>Success!</p>";
        alert("Success!");
    }
    else {
        alert("Errors! Please check 'Status' tab on the right");
        status += "</ul></p>";
    }

    //  status update is displayed and validation status is returned
    showStatus(status);
    return success;
}

function validatePass(pass)
{
    var flag1 = false, flag2 = false;
    
    //  checks if length is 6 and starts with alphabet
    if(pass.length == 6 && ((pass[0] >= 'a' && pass[0] <= 'z') || (pass[0] >= 'A' && pass[0] <= 'Z'))) {
        
        //  checks if number and uppercase character exist in the field
        for(let i = 0; i < pass.length; i++) {
            if(pass[i] >= '0' && pass[i] <= '9') {
                flag1 = true;
            }
            if(pass[i] >='A' && pass[i] <= 'Z') {
                flag2 = true;
            }
        }
    }

    //  returns validation status for password
    return flag1 && flag2;
}

function confirmPass(pass, pass2)
{
    //  returns validation status for second password if it matches first password
    return pass == pass2;
}

function validateUserID(userID)
{
    //  return validation status for username if length is 6 and starts with alphabet
    return (userID.length >= 6 && ((userID[0] >= 'a' && userID[0] <= 'z') || (userID[0] >= 'A' && userID <= 'Z')));
}

function showStatus(msg)
{
    //  replaces the content of the errors container with title and corresponding status message
    document.querySelector('#errors').innerHTML = "<h3>Status</h3>" + msg;
}